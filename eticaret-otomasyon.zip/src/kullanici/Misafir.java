package kullanici;

import static diger.Sabitler.*;

public class Misafir extends Kullanici {

    public Misafir(String ad) {
        super(0, ad, "", "", "", MISAFIR, "");
    }
}